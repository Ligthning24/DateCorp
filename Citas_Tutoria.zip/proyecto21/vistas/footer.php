<footer class="footer">
        <div class="container">
            <div class="footer-row">
                <div class="footer-links">
                    <h4>Citas de tutoria</h4>
                    <ul>
                        <li class="lista"><a href="./datecorp.php">¿Porque Date Corp?</a></li>
                        <li class="lista"><a href="./nosotrosdatecorp.php">Nosotros</a></li>
                    </ul>
                </div>
                
                <div class="footer-links">
                    <h4>Privacidad</h4>
                    <ul>
                        <li class="lista"><a href="./avisodepriv.php">Aviso y privacidad</a></li>
                        <li class="lista"><a href="./avisodediscr.php">Aviso de no discriminacion</a></li>
                    </ul>
                </div>
                <div class="footer-links">
                    <h4>Siguenos</h4>
                    <div class="redessociales">
                        <a href="https://www.facebook.com/profile.php?id=61552327104638"><i class="fab fa-facebook-f"></i></a>
                        <a href="https://www.instagram.com/datecorp/"><i class="fab fa-instagram"></i></a>
                        <a href="https://twitter.com/datecorp2023"><i class="fab fa-twitter"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </footer>