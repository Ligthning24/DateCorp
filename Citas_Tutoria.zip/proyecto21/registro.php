<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario Registro</title>
    <link rel="stylesheet" href="css/estilos_registro.css">
</head>
<body>


    
    <section class="form-register">
        <h4>Formulario Registro</h4>
        <input class="controls" type="text" name="nombres" id="nombres" placeholder="Ingrese su Nombre">
        <input class="controls" type="text" name="apellidos" id="apellidos" placeholder="Ingrese su Apellido">
        <input class="controls" type="email" name="correo" id="correo" placeholder="Ingrese su Correo Electrónico">
        <input class="controls" type="password" name="correo" id="correo" placeholder="Ingrese su Contraseña">
        <input class="botons" type="submit" value="Registrar">

        
        <p><a href="#">¿Ya tengo Cuenta?</a></p>
        <p>¿Olvidaste Contraseña? <a href="contrasenia.php">Haz clic aquí</a></p>

    </section>


</body>
</html>