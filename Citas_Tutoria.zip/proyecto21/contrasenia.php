<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario Registro</title>
    <link rel="stylesheet" href="css/estilos_contrasenia.css">
</head>
<body>


    
    <section class="form-register">
        <h4>Recupera tu cuenta</h4>
        <h5>Ingresa tu correo electrónico para buscar tu cuenta</h5>

        <input class="controls" type="text" name="nombres" id="nombres" placeholder="Correo Electrónico">

        <input class="botons" type="submit" value="Registrar">

        
        
    </section>


</body>
</html>